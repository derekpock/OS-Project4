#!/bin/bash

gcc --std=c11 -lpthread -o pthread pthread.c
