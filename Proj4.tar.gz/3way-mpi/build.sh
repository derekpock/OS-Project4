#!/bin/bash

mpicc -o mpi mpi.c
