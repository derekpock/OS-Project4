#!/bin/bash

gcc --std=c11 -fopenmp -o openmp openmp.c
